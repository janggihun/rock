package com.game.mafia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MafiaApplicationTests {

	@Test
	void contextLoads() {
	}

}
