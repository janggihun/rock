package com.game.mafia.repository;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.game.mafia.dao.UserDao;
import com.game.mafia.dto.UserDto;

import lombok.extern.slf4j.Slf4j;

@Repository
@Slf4j
public class UserRepository {

	@Autowired
	UserDao userDao;

	public int idRegister(UserDto userDto) {

		if (userDao.sameIdCheck(userDto) != null) {
			log.info("==============중복된아이디");
			return 0;
		} else {
			return userDao.idRegister(userDto);
		}
	}

	
	public String idLogin(UserDto userDto) {
		String userId = userDto.getUserId();
		String userPw = userDto.getUserPw();
		Map<?, ?> uMap = userDao.sameIdCheck(userDto);

		if (uMap != null) {
			if (uMap.get("userPw").equals(userPw)) {
				log.info("=======같음");
				return userId;
			}
		}
		return null;
	}
}
