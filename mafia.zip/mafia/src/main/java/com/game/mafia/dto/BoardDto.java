package com.game.mafia.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class BoardDto {

	private int boardNum; //방번호

	private String userId1; //현재 방에 있는사람
	private String userId2;//현재 방에 있는사람
	
}
