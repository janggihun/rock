package com.game.mafia.dao;



import java.util.List;
import java.util.Map;
import org.apache.ibatis.annotations.Mapper;
import com.game.mafia.dto.UserDto;


@Mapper
public interface UserDao {
	
	
	Map<?, ?> sameIdCheck(UserDto userDto); //아이디 검사 / 찾으면1
	
	UserDto idLogin(UserDto userDto); //로그인체크

	int idRegister(UserDto userDto); //회원등록

	
	
	

}
