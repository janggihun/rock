package com.game.mafia.controller;

import java.net.http.HttpRequest;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.game.mafia.dto.BoardDto;
import com.game.mafia.dto.RankDto;

import com.game.mafia.service.BoardService;

import jakarta.security.auth.message.callback.PrivateKeyCallback.Request;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class BoardController {

	@Autowired
	BoardService boardService;

	@GetMapping("/board/main")
	public String boardMain(HttpSession session) {
		// 보드리스트 내용 가지고와서 bList에 담음
		session.setAttribute("bList", boardService.boardInfo());

		return "main";
	}

	@GetMapping("/board/createroom") // 방생성하는 홈페이지로 이동
	public String createRoom() {

		return "createRoom";
	}

	@GetMapping("/board/gameroom")
	public String boardGame() {

		return "gameRoom";
	}

	@GetMapping("/board/back")
	public String boardback(HttpSession session) {
		String userId = (String) session.getAttribute("userId");
		boardService.idCheckRoom(userId); 
		boardService.boardDelete();
		return "redirect:/board/main";
	}
	
	@GetMapping("/board/create/gameroom") // 방생성 버튼 누름
	public String createRoom(BoardDto boardDto, HttpSession session) {
		String userId = (String) session.getAttribute("userId");
		boardDto.setUserId1(userId);
		boardService.userInputRoom(boardDto);
		return "redirect:/board/gameroom";
	}

	@GetMapping("/board/gamecheck")  //게임방 참가 눌렀을때 userId남는곳에 넣어줘야됨
	public String boardGame(BoardDto boardDto, HttpSession session,HttpServletRequest request) {
		
		String userId = (String) session.getAttribute("userId");
		//들어가기전에 들어간곳은 전부 삭제해줌
		boardService.idCheckRoom(userId); //
		// 게임방 참가
		String boardNum = request.getParameter("boardNum");
		
		boardDto.setBoardNum(Integer.parseInt(boardNum));
		log.info("==========={}",boardDto);
		BoardDto bDto =  boardService.roomInfo(boardDto);	
		log.info("==========={}",bDto);
		
	
		if(bDto.getUserId1().equals("")) {
			// 입장가능
			boardDto.setUserId1(userId);
			boardService.userInputRoom1(boardDto);
			
			return "redirect:/board/gameroom";
			
		}else if(bDto.getUserId2().equals("")){
			boardDto.setUserId2(userId);
			boardService.userInputRoom2(boardDto);
			return "redirect:/board/gameroom";
		}else {
			//누군가 다 들어가있어서 입장불가능
			session.setAttribute("msg","full");
			return "redirect:/board/main";
		}
		
		
		
		
	}

}
