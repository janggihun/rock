package com.game.mafia.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.game.mafia.dao.RankDao;
import com.game.mafia.dto.BoardDto;
import com.game.mafia.dto.RankDto;
import com.game.mafia.dto.UserDto;
import com.game.mafia.repository.BoardRepository;

@Service
public class BoardService {

	@Autowired
	BoardRepository boardRepository;

	public List<BoardDto> boardInfo() {

		return boardRepository.boardInfo();
		
	}

	public int userInputRoom1(BoardDto boardDto) {
		return boardRepository.userInputRoom1(boardDto);
	}

	public int userInputRoom2(BoardDto boardDto) {
		return boardRepository.userInputRoom2(boardDto);
		
	}

	public void boardDelete() {
		
		boardRepository.boardDelete();
		
	}

	public BoardDto roomInfo(BoardDto boardDto) {
		
		return boardRepository.roomInfo(boardDto);
	}

	public void userInputRoom(BoardDto boardDto) {
		
		boardRepository.userInputRoom(boardDto);
	}

	
	public void idCheckRoom(String userId) {
		boardRepository.idCheckRoom1(userId);
		boardRepository.idCheckRoom2(userId);
		
	}



}
