package com.game.mafia.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class GameDto {

	private int gameNum;
	private String userId1;
	private int winLose1;
	private String userId2;
	private int winLose2;
}
