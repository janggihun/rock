package com.game.mafia.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class RankDto {

	
	private int boardNum;
	private int gameNum;
	private String userId;
	private int winLose; 
	
	
}
