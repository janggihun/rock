package com.game.mafia.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.game.mafia.dao.BoardDao;
import com.game.mafia.dto.BoardDto;
import com.game.mafia.dto.RankDto;

import groovy.util.logging.Slf4j;

@Repository
@lombok.extern.slf4j.Slf4j
public class BoardRepository {

	@Autowired
	BoardDao boardDao;

	public List<BoardDto> boardInfo() {

		return boardDao.boardInfo();
	}

	public int userInputRoom1(BoardDto boardDto) {

		return boardDao.userInputRoom1(boardDto);
	}
	public int userInputRoom2(BoardDto boardDto) {
		return boardDao.userInputRoom2(boardDto);
	}
	public void boardDelete() {

		boardDao.boardDelete();
	}

	public BoardDto roomInfo(BoardDto boardDto) {
		
		return boardDao.roomInfo(boardDto);

	}

	public void userInputRoom(BoardDto boardDto) {
		
		boardDao.userInputRoom(boardDto);
		
	}

	public void idCheckRoom1(String userId) {
		boardDao.idCheckRoom1(userId);
		
	}

	public void idCheckRoom2(String userId) {
		boardDao.idCheckRoom2(userId);
		
	}

	

}
