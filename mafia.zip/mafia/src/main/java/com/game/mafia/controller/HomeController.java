package com.game.mafia.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.game.mafia.dto.UserDto;
import com.game.mafia.service.UserService;

import jakarta.servlet.http.HttpSession;
import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class HomeController {

	@Autowired
	UserService userService;

//////////////////////get////////////////////////////
	@GetMapping("/")
	public String home() {

		return "index";
	}

	@GetMapping("/home/login")
	public String login() {
		return "login";
	}

	@GetMapping("/home/logout") 
	public String logout(HttpSession session) {
		//로그아웃시 세션내용제거
		session.invalidate();
		return "redirect:/home/login";
	}

	@GetMapping("/home/register")
	public String register() {
		return "register";
	}

	@GetMapping("/home/main")
	public String main() {

		return "main";
	}

//////////////////////post////////////////////////////

	@PostMapping("/home/login")
	public String idLogin(UserDto userDto, HttpSession session) {
		//세션에 id값 저장
		session.setAttribute("userId", userService.idLogin(userDto)); 

		return "redirect:/board/main";
	}

	@PostMapping("/home/register")
	public String idRegister(UserDto userDto) {
		int result = userService.idRegister(userDto);

		if (result == 1) {// 성공

			return "redirect:/home/login";
		} else {// 실패

			return "redirect:/home/register";

		}
	}
}
