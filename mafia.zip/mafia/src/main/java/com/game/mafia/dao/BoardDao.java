package com.game.mafia.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.game.mafia.dto.BoardDto;
import com.game.mafia.dto.RankDto;

@Mapper
public interface BoardDao {

	List<BoardDto> boardInfo();

	
	
	int userInputRoom1(BoardDto boardDto);
	int userInputRoom2(BoardDto boardDto);

	BoardDto roomCheck(BoardDto boardDto);
	
	BoardDto roomInfo(BoardDto boardDto);
	
	boolean boardDelete();

	int idCheckRoom1(String userId);
	int idCheckRoom2(String userId);
	
	int userInputRoom(BoardDto boardDto);

	
	
}
