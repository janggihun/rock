package com.game.mafia.dao;



public interface RankDao {

}
