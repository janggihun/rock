package com.game.mafia.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class RestPostController {
	
	
	
}
