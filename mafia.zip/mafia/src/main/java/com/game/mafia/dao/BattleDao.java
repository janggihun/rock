package com.game.mafia.dao;

public interface BattleDao {

}
