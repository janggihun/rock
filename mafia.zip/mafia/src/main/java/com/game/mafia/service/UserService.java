package com.game.mafia.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.game.mafia.dto.UserDto;
import com.game.mafia.repository.UserRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class UserService {

	@Autowired
	UserRepository userRepository;

	public String idLogin(UserDto userDto) { // 로그인

		return userRepository.idLogin(userDto);

	}

	public int idRegister(UserDto userDto) { // 가입
		log.info("========{}", userDto);

		return userRepository.idRegister(userDto);

	}

}
