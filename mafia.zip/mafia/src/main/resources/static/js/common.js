/**
 * 
 */
let msg = window.sessionStorage.getItem("msg")	
window.onload = function() {
	
	if (msg != '' && msg != null) {
		alert(msg)
	}
}


